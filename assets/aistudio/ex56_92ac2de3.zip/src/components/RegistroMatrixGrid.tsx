import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Resource, ActivityGroup, DayInfo, DailyResourceLog, ResourceAvailability, DayResourceState } from '../types';
import { 
  ChevronLeft, 
  ChevronRight, 
  Edit2, 
  Trash2, 
  Check, 
  Plus, 
  Coins, 
  SlidersHorizontal,
  CalendarDays,
  DollarSign,
  ShoppingBag,
  RotateCcw,
  Sparkles,
  X,
  Clock
} from 'lucide-react';

interface RegistroMatrixGridProps {
  days: DayInfo[];
  resources: Resource[];
  groups: ActivityGroup[];
  resourceLogs?: Record<string, DailyResourceLog>;
  onToggleResourceBought: (resourceId: string, dateStr: string) => void;
  onUpdateResourceDayCost: (resourceId: string, dateStr: string, cost: number) => void;
  onUpdateResourceStatus?: (resourceId: string, newAvailability: ResourceAvailability) => void;
  onRenewResource?: (resourceId: string, dateStr: string, renewalCost?: number) => void;
  onSetDayResourceState?: (resourceId: string, dateStr: string, state: DayResourceState, cost?: number) => void;
  onAddResource: () => void;
  onEditResource: (resource: Resource) => void;
  onDeleteResource: (resourceId: string) => void;
  onPrevDateWindow: () => void;
  onNextDateWindow: () => void;
  onTodayWindow: () => void;
  onOpenTimeSettings: () => void;
  activeFilterGroup?: string | null;
  onSetFilterGroup?: (groupId: string | null) => void;
}

export const RegistroMatrixGrid: React.FC<RegistroMatrixGridProps> = ({
  days,
  resources,
  groups,
  resourceLogs = {},
  onToggleResourceBought,
  onUpdateResourceDayCost,
  onUpdateResourceStatus,
  onRenewResource,
  onSetDayResourceState,
  onAddResource,
  onEditResource,
  onDeleteResource,
  onPrevDateWindow,
  onNextDateWindow,
  onTodayWindow,
  onOpenTimeSettings,
  activeFilterGroup,
  onSetFilterGroup,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [editingCostCell, setEditingCostCell] = useState<{ id: string; date: string } | null>(null);
  const [tempCostValue, setTempCostValue] = useState<string>('');

  // Duration action popover state
  const [activeDurationPopover, setActiveDurationPopover] = useState<{
    resId: string;
    dateStr: string;
    dayNumber: number;
    dayName: string;
    currentState: DayResourceState;
    currentCost: number;
  } | null>(null);

  const [renewalInputCost, setRenewalInputCost] = useState<string>('');

  // Strictly filter to resource groups only
  const resourceGroups = useMemo(() => {
    return groups.filter(g => g.type === 'resource');
  }, [groups]);

  // Filter resources
  const filteredResources = useMemo(() => {
    return resources.filter(res => {
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = res.name.toLowerCase().includes(q);
        const matchesCode = res.code ? res.code.toLowerCase().includes(q) : false;
        if (!matchesName && !matchesCode) return false;
      }
      if (activeFilterGroup) {
        if (activeFilterGroup === '__ungrouped__') {
          return !res.groupId;
        }
        return res.groupId === activeFilterGroup;
      }
      return true;
    });
  }, [resources, searchQuery, activeFilterGroup]);

  // Today day reference
  const todayDay = useMemo(() => days.find(d => d.isToday), [days]);

  // Current month determination (from days or today)
  const currentMonthInfo = useMemo(() => {
    const ref = todayDay || days[Math.floor(days.length / 2)] || days[0];
    if (!ref) return { prefix: '2026-11', name: 'este mes' };
    const prefix = ref.dateStr.slice(0, 7); // "YYYY-MM"
    const name = ref.monthName.toLowerCase();
    return { prefix, name };
  }, [todayDay, days]);

  // Helper code for resources
  const getResourceCode = (res: Resource, idx: number) => {
    if (res.code && res.code.trim()) return res.code.trim().toUpperCase();
    return `R${String(idx + 1).padStart(2, '0')}`;
  };

  /**
   * TIMELINE STATE PROPAGATION ALGORITHM
   * For resources with hasDurationStatus:
   * 1. Finds all explicit milestones (renovado, por_agotar, agotado, disponible).
   * 2. After a 'renovado' day, subsequent days automatically become 'disponible'.
   * 3. After 'por_agotar', subsequent days automatically continue as 'por_agotar' until renewed or agotado.
   * 4. After 'agotado', subsequent days continue as 'agotado' until renewed.
   */
  const resourceTimelines = useMemo(() => {
    const map: Record<string, Record<string, { state: DayResourceState; isMilestone: boolean }>> = {};

    for (const res of filteredResources) {
      if (!res.hasDurationStatus) continue;

      const milestonesMap: Record<string, DayResourceState> = {};

      if (res.lastRenewedDate) {
        milestonesMap[res.lastRenewedDate] = 'renovado';
      }

      const prefix = `${res.id}_`;
      for (const [key, log] of Object.entries(resourceLogs)) {
        if (!key.startsWith(prefix)) continue;
        const dStr = key.slice(prefix.length);
        if (log.renewed || log.state === 'renovado') {
          milestonesMap[dStr] = 'renovado';
        } else if (log.state) {
          milestonesMap[dStr] = log.state;
        }
      }

      const sortedDates = Object.keys(milestonesMap).sort();
      const dayMap: Record<string, { state: DayResourceState; isMilestone: boolean }> = {};

      for (const day of days) {
        const d = day.dateStr;
        if (milestonesMap[d]) {
          dayMap[d] = { state: milestonesMap[d], isMilestone: true };
          continue;
        }

        const prior = sortedDates.filter(m => m <= d);
        if (prior.length > 0) {
          const lastDate = prior[prior.length - 1];
          const lastState = milestonesMap[lastDate];
          if (lastState === 'renovado') {
            // Day after renovation continues as disponible!
            dayMap[d] = { state: 'disponible', isMilestone: false };
          } else {
            // por_agotar, agotado, disponible propagate forward
            dayMap[d] = { state: lastState, isMilestone: false };
          }
        } else {
          // No prior milestone
          const base = res.availabilityStatus === 'por_agotarse' ? 'por_agotar' : (res.availabilityStatus || 'disponible');
          dayMap[d] = { state: base as DayResourceState, isMilestone: false };
        }
      }

      map[res.id] = dayMap;
    }

    return map;
  }, [filteredResources, days, resourceLogs]);

  // Monthly stats per resource (Renovaciones en el mes, Gasto total en el mes)
  const resourceMonthlyStats = useMemo(() => {
    const stats: Record<string, { renewalsCount: number; monthSpent: number }> = {};

    for (const res of filteredResources) {
      let renewals = 0;
      let spent = 0;
      const prefix = `${res.id}_${currentMonthInfo.prefix}`;

      for (const [key, log] of Object.entries(resourceLogs)) {
        if (!key.startsWith(prefix)) continue;
        if (log.renewed || log.state === 'renovado') {
          renewals++;
        }
        if (res.hasCost && log.cost && log.cost > 0 && log.bought) {
          spent += log.cost;
        }
      }

      stats[res.id] = {
        renewalsCount: renewals,
        monthSpent: Math.round(spent * 100) / 100,
      };
    }

    return stats;
  }, [filteredResources, currentMonthInfo, resourceLogs]);

  // Read log for a resource and date
  const getResourceDayData = (resId: string, dateStr: string) => {
    const key = `${resId}_${dateStr}`;
    const log = resourceLogs[key];
    const isBought = log?.bought ?? false;
    const costNum = (log?.cost !== undefined && log.cost > 0) ? log.cost : 0;
    return { isBought, costNum, hasCostEntered: costNum > 0 };
  };

  // Daily totals calculations: considers ONLY entries with cost > 0
  const dailyTotals = useMemo(() => {
    const totals: Record<string, { dayTotal: number; boughtTotal: number }> = {};
    for (const day of days) {
      let dTotal = 0;
      let bTotal = 0;
      for (const res of resources) {
        if (!res.hasCost) continue;
        const key = `${res.id}_${day.dateStr}`;
        const log = resourceLogs[key];
        const costVal = (log?.cost !== undefined && log.cost > 0) ? log.cost : 0;
        if (costVal > 0) {
          dTotal += costVal;
          if (log?.bought) {
            bTotal += costVal;
          }
        }
      }
      totals[day.dateStr] = {
        dayTotal: Math.round(dTotal * 100) / 100,
        boughtTotal: Math.round(bTotal * 100) / 100,
      };
    }
    return totals;
  }, [days, resources, resourceLogs]);

  // Today totals
  const todayStats = useMemo(() => {
    if (!todayDay) return { dayTotal: 0, boughtTotal: 0, pendingTotal: 0 };
    const t = dailyTotals[todayDay.dateStr] || { dayTotal: 0, boughtTotal: 0 };
    return {
      dayTotal: t.dayTotal,
      boughtTotal: t.boughtTotal,
      pendingTotal: Math.max(0, Math.round((t.dayTotal - t.boughtTotal) * 100) / 100),
    };
  }, [todayDay, dailyTotals]);

  // Inline editing handlers
  const handleStartEditCost = (resId: string, dateStr: string, currentCost: number) => {
    setEditingCostCell({ id: resId, date: dateStr });
    setTempCostValue(currentCost > 0 ? currentCost.toString() : '');
  };

  const handleSaveCost = (resId: string, dateStr: string) => {
    const val = parseFloat(tempCostValue);
    if (!isNaN(val) && val > 0) {
      onUpdateResourceDayCost(resId, dateStr, Math.round(val * 100) / 100);
    } else {
      onUpdateResourceDayCost(resId, dateStr, 0);
    }
    setEditingCostCell(null);
  };

  // Open popover for duration status day cell
  const handleOpenDurationPopover = (
    res: Resource, 
    day: DayInfo, 
    currentState: DayResourceState, 
    currentCost: number
  ) => {
    setActiveDurationPopover({
      resId: res.id,
      dateStr: day.dateStr,
      dayNumber: day.dayNumber,
      dayName: day.dayName,
      currentState,
      currentCost,
    });
    setRenewalInputCost(currentCost > 0 ? currentCost.toString() : (res.cost > 0 ? res.cost.toString() : ''));
  };

  // Apply state from popover
  const handleApplyStateFromPopover = (newState: DayResourceState) => {
    if (!activeDurationPopover || !onSetDayResourceState) return;
    const { resId, dateStr } = activeDurationPopover;
    const targetResource = resources.find(r => r.id === resId);

    if (newState === 'renovado') {
      const parsedCost = parseFloat(renewalInputCost);
      const finalCost = (!isNaN(parsedCost) && parsedCost > 0) ? Math.round(parsedCost * 100) / 100 : 0;
      if (onRenewResource) {
        onRenewResource(resId, dateStr, finalCost);
      } else {
        onSetDayResourceState(resId, dateStr, 'renovado', finalCost);
      }
    } else {
      onSetDayResourceState(resId, dateStr, newState);
    }
    setActiveDurationPopover(null);
  };

  return (
    <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden flex flex-col">
      
      {/* Registro Controls Header */}
      <div className="p-3 sm:p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/80">
        
        {/* Left: Search & Filter (Only resource groups) */}
        <div className="flex items-center gap-2 flex-1 w-full sm:w-auto">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar registro..."
            className="px-3 py-1.5 sm:py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 w-1/2 sm:w-48 font-medium"
          />

          <div className="flex items-center gap-1.5 flex-1 sm:flex-none min-w-0">
            <SlidersHorizontal className="w-4 h-4 text-slate-400 shrink-0 hidden xs:inline" />
            <select
              value={activeFilterGroup || ''}
              onChange={(e) => onSetFilterGroup && onSetFilterGroup(e.target.value === '' ? null : e.target.value)}
              className="text-xs sm:text-sm bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 sm:py-2 text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 w-full sm:w-auto truncate font-medium"
            >
              <option value="">Todos los registros ({filteredResources.length})</option>
              {resourceGroups.map((g) => (
                <option key={g.id} value={g.id}>
                  {g.code ? `[${g.code}] ` : ''}{g.name}
                </option>
              ))}
            </select>
          </div>

          <button
            type="button"
            onClick={onAddResource}
            className="inline-flex items-center gap-1 px-3 py-1.5 sm:py-2 text-xs sm:text-sm font-bold rounded-xl transition-all border border-amber-400 bg-amber-400 hover:bg-amber-500 text-slate-950 shadow-2xs cursor-pointer whitespace-nowrap active:scale-95"
            title="Crear un nuevo recurso o registro de gasto"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span className="hidden sm:inline">Nuevo Registro</span>
            <span className="sm:hidden">Nuevo</span>
          </button>
        </div>

        {/* Right: Date navigation window */}
        <div className="flex items-center gap-2 justify-between sm:justify-end w-full sm:w-auto flex-wrap">
          <button
            onClick={onTodayWindow}
            className="px-3 py-1.5 sm:py-2 text-xs sm:text-sm font-bold text-amber-950 bg-amber-100 hover:bg-amber-200 rounded-xl transition-colors border border-amber-300 shadow-2xs cursor-pointer whitespace-nowrap active:scale-95"
          >
            Hoy
          </button>

          <button
            onClick={onOpenTimeSettings}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 sm:py-2 text-xs sm:text-sm font-semibold text-slate-700 bg-white hover:bg-amber-50/70 hover:text-amber-900 hover:border-amber-200 border border-slate-200 rounded-xl transition-colors shadow-2xs cursor-pointer whitespace-nowrap"
            title="Elegir fechas de inicio y fin o marcar 7, 14 o 30 días"
          >
            <CalendarDays className="w-4 h-4 text-amber-600 shrink-0" />
            <span className="hidden xs:inline">Establecer Tiempos</span>
            <span className="xs:hidden">Tiempos</span>
          </button>
          
          <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-xl p-0.5 shrink-0 shadow-2xs">
            <button
              onClick={onPrevDateWindow}
              className="p-1 sm:p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              title="Período anterior"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs sm:text-sm font-bold text-slate-700 px-1.5 sm:px-2.5 select-none whitespace-nowrap">
              {days[0]?.dayNumber} {days[0]?.monthName?.slice(0, 3)} - {days[days.length - 1]?.dayNumber} {days[days.length - 1]?.monthName?.slice(0, 3)}
            </span>
            <button
              onClick={onNextDateWindow}
              className="p-1 sm:p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              title="Período siguiente"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>

      {/* Today Financial Summary Strip */}
      {todayDay && (
        <div className="bg-gradient-to-r from-amber-50 via-slate-50 to-emerald-50 px-4 py-2.5 border-b border-slate-200 flex items-center justify-between flex-wrap gap-2 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-slate-900 flex items-center gap-1.5">
              <ShoppingBag className="w-4 h-4 text-amber-600" />
              Gastos de Hoy ({todayDay.dayName} {todayDay.dayNumber} {todayDay.monthName}):
            </span>
          </div>

          <div className="flex items-center gap-3 sm:gap-6 flex-wrap font-semibold">
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500">Total del día:</span>
              <span className="font-mono font-bold text-slate-900 bg-white px-2 py-0.5 rounded-md border border-slate-200 shadow-2xs">
                S/. {todayStats.dayTotal.toFixed(2)}
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <span className="text-emerald-700 font-bold flex items-center gap-1">
                <Check className="w-3.5 h-3.5" />
                Comprado actual:
              </span>
              <span className="font-mono font-extrabold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-md border border-emerald-300 shadow-2xs">
                S/. {todayStats.boughtTotal.toFixed(2)}
              </span>
            </div>

            {todayStats.pendingTotal > 0 && (
              <div className="flex items-center gap-1.5">
                <span className="text-amber-800">Falta comprar:</span>
                <span className="font-mono font-bold text-amber-900 bg-amber-100/80 px-2 py-0.5 rounded-md border border-amber-300 shadow-2xs">
                  S/. {todayStats.pendingTotal.toFixed(2)}
                </span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Registro Table with STRICT FIXED Day Column Widths (110px) and FIXED Cell Heights (64px) */}
      <div className="overflow-x-auto matrix-scroll w-full relative">
        <table className="border-collapse text-left w-max min-w-full">
          <thead>
            <tr className="bg-slate-100/95 border-b border-slate-200 text-xs sm:text-sm font-semibold text-slate-700 sticky top-0 z-20 h-14">
              
              {/* Sticky Left Column Header (Record / Resource) */}
              <th
                className="sticky left-0 z-25 bg-slate-100 p-2 sm:p-2.5 border-r border-slate-200 shadow-[1px_0_0_0_#e2e8f0] select-none w-[280px] min-w-[280px] max-w-[280px]"
              >
                <div className="flex items-center justify-between gap-1 px-1">
                  <span className="font-bold text-slate-900 text-xs sm:text-sm truncate">
                    Registros / Recursos
                  </span>
                  <span className="text-[11px] font-mono text-slate-400 font-normal">
                    ({filteredResources.length})
                  </span>
                </div>
              </th>

              {/* Day Columns Headers with strictly fixed width w-[110px] */}
              {days.map((day) => {
                return (
                  <th
                    key={day.dateStr}
                    className={`w-[110px] min-w-[110px] max-w-[110px] py-2 px-1 text-center transition-colors ${
                      day.isToday 
                        ? 'bg-amber-200/95 font-black text-amber-950 border-x-2 border-amber-400 shadow-[inset_0_0_0_1px_rgba(245,158,11,0.25)]' 
                        : 'border-r border-slate-200'
                    } ${day.isWeekend && !day.isToday ? 'bg-slate-100/70' : ''}`}
                  >
                    <div className="flex flex-col items-center">
                      <span className={`text-[10px] sm:text-xs uppercase tracking-wider ${
                        day.isToday ? 'text-amber-950 font-black' : 'text-slate-500 font-semibold'
                      }`}>
                        {day.dayName}
                      </span>
                      <span className={`text-xs sm:text-sm my-0.5 leading-none ${
                        day.isToday 
                          ? 'w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center font-extrabold shadow-xs' 
                          : 'font-bold text-slate-700'
                      }`}>
                        {day.dayNumber}
                      </span>
                      <span className={`text-[9px] sm:text-[10px] font-medium leading-none ${
                        day.isToday ? 'text-amber-900 font-bold' : 'text-slate-400'
                      }`}>
                        {day.monthName.slice(0, 3)}
                      </span>
                    </div>
                  </th>
                );
              })}
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-100">
            {filteredResources.length === 0 ? (
              <tr>
                <td colSpan={days.length + 1} className="py-12 text-center text-slate-400 text-xs sm:text-sm">
                  <Coins className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  No hay registros creados todavía.
                  <div className="mt-2">
                    <button
                      type="button"
                      onClick={onAddResource}
                      className="px-3 py-1.5 bg-amber-400 text-slate-950 font-bold rounded-lg text-xs hover:bg-amber-500 cursor-pointer"
                    >
                      + Crear primer registro
                    </button>
                  </div>
                </td>
              </tr>
            ) : (
              /* NO GROUP HEADERS: Render resources directly with group info underneath, identical to Daily Missions */
              filteredResources.map((res, rIdx) => {
                const resCode = getResourceCode(res, rIdx);
                const assignedGroup = groups.find(g => g.id === res.groupId);
                const groupColor = assignedGroup?.color || '#06b6d4';
                const groupCode = assignedGroup?.code || 'REC';
                const groupName = assignedGroup?.name || 'General';

                const hasDuration = !!res.hasDurationStatus;
                const timeline = resourceTimelines[res.id] || {};
                const mStats = resourceMonthlyStats[res.id] || { renewalsCount: 0, monthSpent: 0 };

                return (
                  <tr key={res.id} className="hover:bg-amber-50/20 transition-colors group h-[68px] min-h-[68px] max-h-[68px]">
                    
                    {/* Sticky Left Resource Card (with Name on top, Group details underneath + Monthly metrics) */}
                    <td
                      className="sticky left-0 z-10 bg-white group-hover:bg-amber-50/30 p-2 sm:p-2.5 border-r border-slate-200 shadow-[1px_0_0_0_#e2e8f0] w-[280px] min-w-[280px] max-w-[280px] h-[68px] min-h-[68px] max-h-[68px] align-middle"
                    >
                      <div className="flex flex-col justify-center h-full gap-1 min-w-0">
                        {/* Top Line: Code pill, Name, and Actions */}
                        <div className="flex items-center justify-between gap-1.5 min-w-0">
                          <div className="flex items-center gap-1.5 min-w-0">
                            <span className="font-mono text-[10px] font-black text-slate-700 px-1 py-0.5 rounded bg-slate-100 border border-slate-200 shrink-0">
                              {resCode}
                            </span>
                            <span 
                              className="font-bold text-slate-900 text-xs sm:text-sm truncate cursor-pointer hover:text-amber-800"
                              onClick={() => onEditResource(res)}
                              title={res.name}
                            >
                              {res.name}
                            </span>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={() => onEditResource(res)}
                              className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-amber-700 p-1 rounded hover:bg-slate-100 transition-opacity cursor-pointer"
                              title="Configurar registro"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => onDeleteResource(res.id)}
                              className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-rose-600 p-1 rounded hover:bg-rose-50 transition-opacity cursor-pointer"
                              title="Eliminar registro"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* Bottom Line: Group Info (Color Dot, Group Code, Group Name) + Monthly Metrics */}
                        <div className="flex items-center justify-between gap-1 flex-wrap">
                          {/* Group identity line identical to daily missions */}
                          <div className="flex items-center gap-1.5 text-[11px] text-slate-500 truncate">
                            <span
                              className="w-2 h-2 rounded-full shrink-0 shadow-xs"
                              style={{ backgroundColor: groupColor }}
                            />
                            <span
                              className="font-mono font-bold text-[10px] px-1 py-0.2 rounded"
                              style={{
                                backgroundColor: `${groupColor}1f`,
                                color: groupColor,
                              }}
                            >
                              {groupCode}
                            </span>
                            <span className="truncate font-medium text-slate-600">
                              {groupName}
                            </span>
                          </div>

                          {/* Monthly metrics (Renovaciones en el mes & Gasto total del mes) */}
                          <div className="flex items-center gap-1 shrink-0">
                            {hasDuration && (
                              <span 
                                className="text-[10px] font-bold text-cyan-800 bg-cyan-50 px-1.5 py-0.5 rounded border border-cyan-200"
                                title={`Renovado ${mStats.renewalsCount} veces en ${currentMonthInfo.name}`}
                              >
                                {mStats.renewalsCount}x renovado
                              </span>
                            )}

                            {res.hasCost && mStats.monthSpent > 0 && (
                              <span 
                                className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200"
                                title={`Total gastado en ${currentMonthInfo.name}: S/. ${mStats.monthSpent.toFixed(2)}`}
                              >
                                S/.{mStats.monthSpent.toFixed(2)} mes
                              </span>
                            )}
                          </div>
                        </div>

                      </div>
                    </td>

                    {/* Day Columns for this Resource: STRICT FIXED WIDTH w-[110px] and STRICT FIXED HEIGHT h-[68px] */}
                    {days.map((day) => {
                      const { isBought, costNum, hasCostEntered } = getResourceDayData(res.id, day.dateStr);
                      const isEditingThisCell = editingCostCell?.id === res.id && editingCostCell?.date === day.dateStr;

                      // State for duration resources
                      const dayTimeline = timeline[day.dateStr] || { state: 'disponible', isMilestone: false };
                      const dayState = dayTimeline.state;

                      return (
                        <td
                          key={day.dateStr}
                          className={`p-1.5 border-r border-slate-200 transition-colors align-middle text-center w-[110px] min-w-[110px] max-w-[110px] h-[68px] min-h-[68px] max-h-[68px] ${
                            day.isToday ? 'bg-amber-50/50' : ''
                          }`}
                        >
                          {/* CASE 1: RESOURCE WITH DURATION STATUS (E.g. Rastrillos, Jabón, Desodorante, Ropa de color) */}
                          {hasDuration ? (
                            <div 
                              onClick={() => handleOpenDurationPopover(res, day, dayState, costNum)}
                              className={`w-[98px] h-[52px] min-h-[52px] max-h-[52px] mx-auto py-1 px-1 rounded-xl transition-all border flex flex-col items-center justify-center gap-0.5 cursor-pointer shadow-2xs select-none ${
                                dayState === 'renovado'
                                  ? 'bg-cyan-100 text-cyan-950 border-cyan-400 font-bold hover:bg-cyan-200/80'
                                  : dayState === 'por_agotar'
                                    ? 'bg-amber-100 text-amber-950 border-amber-400 font-bold hover:bg-amber-200/80'
                                    : dayState === 'agotado'
                                      ? 'bg-rose-100 text-rose-950 border-rose-400 font-bold hover:bg-rose-200/80'
                                      : 'bg-emerald-50 text-emerald-950 border-emerald-300 font-semibold hover:bg-emerald-100/80'
                              }`}
                              title={`Estado: ${dayState}. Haz clic para cambiar estado o renovar.`}
                            >
                              {/* Top: Status Pill */}
                              <div className="flex items-center gap-1 leading-none">
                                {dayState === 'renovado' ? (
                                  <>
                                    <Sparkles className="w-3 h-3 text-cyan-700 shrink-0" />
                                    <span className="text-[10px] font-black uppercase tracking-tight">Renovado</span>
                                  </>
                                ) : dayState === 'por_agotar' ? (
                                  <span className="text-[10px] font-extrabold uppercase tracking-tight">Por agotar</span>
                                ) : dayState === 'agotado' ? (
                                  <span className="text-[10px] font-black uppercase tracking-tight">Agotado</span>
                                ) : (
                                  <span className="text-[10px] font-bold text-emerald-800">Disponible</span>
                                )}
                              </div>

                              {/* Bottom: Price if renewed & has cost, or status sub-text */}
                              <div className="leading-none text-center">
                                {res.hasCost ? (
                                  hasCostEntered ? (
                                    <span className="text-[11px] font-mono font-black text-slate-900">
                                      S/. {costNum.toFixed(2)}
                                    </span>
                                  ) : dayState === 'renovado' ? (
                                    <span className="text-[9px] text-cyan-800 font-semibold underline">
                                      + precio
                                    </span>
                                  ) : (
                                    <span className="text-[9px] opacity-70">
                                      {dayTimeline.isMilestone ? '● hito' : 'en uso'}
                                    </span>
                                  )
                                ) : (
                                  <span className="text-[9px] opacity-75 font-medium">
                                    {dayState === 'renovado' ? '✓ renovado' : 'sin costo'}
                                  </span>
                                )}
                              </div>
                            </div>
                          ) : res.hasCost ? (
                            /* CASE 2: REGULAR RECURRING RESOURCE WITH PRICE (E.g. Desayunos, Cenas, Pasajes) */
                            <div className={`w-[98px] h-[52px] min-h-[52px] max-h-[52px] mx-auto py-1 px-1 rounded-xl transition-all border flex flex-col items-center justify-center gap-1 ${
                              hasCostEntered && isBought
                                ? 'bg-emerald-100/90 border-emerald-400 text-emerald-950 shadow-2xs'
                                : hasCostEntered
                                  ? 'bg-white border-amber-300 shadow-2xs'
                                  : 'bg-white border-slate-200 hover:border-slate-300'
                            }`}>
                              
                              {/* Price Row: Fits S/. and number in ONE line */}
                              {isEditingThisCell ? (
                                <div className="flex items-center justify-center gap-0.5 w-full">
                                  <span className="text-[11px] font-bold text-slate-500 shrink-0">S/.</span>
                                  <input
                                    type="number"
                                    step="0.10"
                                    min="0"
                                    autoFocus
                                    placeholder="0.00"
                                    value={tempCostValue}
                                    onChange={(e) => setTempCostValue(e.target.value)}
                                    onBlur={() => handleSaveCost(res.id, day.dateStr)}
                                    onKeyDown={(e) => {
                                      if (e.key === 'Enter') handleSaveCost(res.id, day.dateStr);
                                      if (e.key === 'Escape') setEditingCostCell(null);
                                    }}
                                    className="w-14 text-center text-xs font-mono font-bold bg-white border border-amber-400 rounded px-1 py-0.5 focus:outline-hidden"
                                  />
                                </div>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => handleStartEditCost(res.id, day.dateStr, costNum)}
                                  className={`text-xs font-mono font-bold px-1 py-0.2 rounded cursor-pointer transition-colors w-full truncate text-center ${
                                    hasCostEntered && isBought 
                                      ? 'text-emerald-950 font-black hover:bg-emerald-200/60' 
                                      : hasCostEntered
                                        ? 'text-slate-900 font-bold hover:bg-slate-100'
                                        : 'text-slate-300 hover:text-slate-600 hover:bg-slate-50'
                                  }`}
                                  title={hasCostEntered ? 'Haz clic para modificar el costo de este día' : 'Haz clic para ingresar precio a este día'}
                                >
                                  {hasCostEntered ? (
                                    <span>S/. {costNum.toFixed(2)}</span>
                                  ) : (
                                    <span className="text-[11px] text-slate-300 font-normal">0.00</span>
                                  )}
                                </button>
                              )}

                              {/* Comprado / Falta Button (Displayed when price > 0, otherwise subtle + precio button) */}
                              {hasCostEntered ? (
                                <button
                                  type="button"
                                  onClick={() => onToggleResourceBought(res.id, day.dateStr)}
                                  className={`w-full py-0.5 px-1 rounded-md text-[10px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1 active:scale-95 ${
                                    isBought
                                      ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-2xs'
                                      : 'bg-slate-100 text-slate-600 hover:bg-amber-100 hover:text-amber-900 border border-slate-200'
                                  }`}
                                  title={isBought ? 'Comprado hoy. Haz clic para cambiar a falta.' : 'Marcar como comprado este día'}
                                >
                                  {isBought ? (
                                    <>
                                      <Check className="w-3 h-3 stroke-[3]" />
                                      <span>Comprado</span>
                                    </>
                                  ) : (
                                    <span>Falta</span>
                                  )}
                                </button>
                              ) : (
                                <div 
                                  onClick={() => handleStartEditCost(res.id, day.dateStr, 0)}
                                  className="w-full py-0.5 text-[9px] text-slate-300 hover:text-slate-500 cursor-pointer text-center select-none"
                                >
                                  + precio
                                </div>
                              )}

                            </div>
                          ) : (
                            /* CASE 3: NO COST & NO DURATION */
                            <div className="w-[98px] h-[52px] min-h-[52px] max-h-[52px] mx-auto flex items-center justify-center text-slate-300 select-none text-xs">
                              —
                            </div>
                          )}
                        </td>
                      );
                    })}

                  </tr>
                );
              })
            )}

            {/* SUMMARY ROW 1: TOTAL DEL DÍA (Presupuesto total ingresado con costo > 0) */}
            <tr className="bg-slate-100/95 font-bold text-xs text-slate-900 border-t-2 border-slate-300 h-12 min-h-12 max-h-12">
              <td
                className="sticky left-0 z-10 bg-slate-100 p-2 sm:p-2.5 border-r border-slate-300 shadow-[1px_0_0_0_#cbd5e1] w-[280px] min-w-[280px] max-w-[280px]"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <DollarSign className="w-4 h-4 text-slate-600" />
                    <span className="font-extrabold text-slate-900 text-xs sm:text-sm">
                      Total del día
                    </span>
                  </div>
                  <span className="text-[10px] font-medium text-slate-500">
                    (Gastos previstos)
                  </span>
                </div>
              </td>

              {days.map((day) => {
                const total = dailyTotals[day.dateStr]?.dayTotal || 0;
                return (
                  <td
                    key={day.dateStr}
                    className={`p-2 text-center border-r border-slate-200/80 font-mono text-xs sm:text-sm font-bold text-slate-900 w-[110px] min-w-[110px] max-w-[110px] ${
                      day.isToday ? 'bg-amber-100/70 text-amber-950 font-black' : ''
                    }`}
                  >
                    S/. {total.toFixed(2)}
                  </td>
                );
              })}
            </tr>

            {/* SUMMARY ROW 2: TOTAL ACTUAL (COMPRADO) */}
            <tr className="bg-emerald-50/90 font-bold text-xs text-emerald-950 border-t border-emerald-200 h-12 min-h-12 max-h-12">
              <td
                className="sticky left-0 z-10 bg-emerald-50 p-2 sm:p-2.5 border-r border-emerald-300 shadow-[1px_0_0_0_#a7f3d0] w-[280px] min-w-[280px] max-w-[280px]"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Check className="w-4 h-4 text-emerald-700 stroke-[2.5]" />
                    <span className="font-extrabold text-emerald-950 text-xs sm:text-sm">
                      Total actual
                    </span>
                  </div>
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded">
                    Solo Comprado
                  </span>
                </div>
              </td>

              {days.map((day) => {
                const boughtTotal = dailyTotals[day.dateStr]?.boughtTotal || 0;
                return (
                  <td
                    key={day.dateStr}
                    className={`p-2 text-center border-r border-emerald-200 font-mono text-xs sm:text-sm font-black text-emerald-800 w-[110px] min-w-[110px] max-w-[110px] ${
                      day.isToday ? 'bg-emerald-200/70 text-emerald-950 font-black' : ''
                    }`}
                  >
                    S/. {boughtTotal.toFixed(2)}
                  </td>
                );
              })}
            </tr>

          </tbody>
        </table>
      </div>

      {/* DURATION STATE MODAL / POPOVER */}
      {activeDurationPopover && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/30">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-sm p-4 space-y-3.5 animate-in fade-in zoom-in-95">
            
            {/* Popover Header */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-cyan-700" />
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-slate-900">
                    {resources.find(r => r.id === activeDurationPopover.resId)?.name}
                  </h3>
                  <p className="text-[11px] text-slate-500 font-medium">
                    {activeDurationPopover.dayName} {activeDurationPopover.dayNumber} ({activeDurationPopover.dateStr})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveDurationPopover(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Options */}
            <div className="space-y-2 text-xs">
              
              {/* Option 1: Marcar Renovado */}
              <div className="p-2.5 rounded-xl border border-cyan-300 bg-cyan-50/60 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-cyan-950 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-cyan-700" />
                    ★ Marcar Renovado este día
                  </span>
                  <button
                    type="button"
                    onClick={() => handleApplyStateFromPopover('renovado')}
                    className="px-3 py-1 bg-cyan-600 hover:bg-cyan-700 text-white font-bold rounded-lg text-xs cursor-pointer shadow-xs active:scale-95"
                  >
                    Renovar
                  </button>
                </div>

                <p className="text-[11px] text-slate-600 leading-tight">
                  Al renovar, los días posteriores se actualizarán automáticamente como <strong>Disponible</strong>.
                </p>

                {/* If resource has cost, enter renewal price */}
                {resources.find(r => r.id === activeDurationPopover.resId)?.hasCost && (
                  <div className="flex items-center gap-2 pt-1 border-t border-cyan-200">
                    <span className="font-bold text-cyan-950 text-xs">Precio de renovación: S/.</span>
                    <input
                      type="number"
                      step="0.10"
                      min="0"
                      placeholder="0.00"
                      value={renewalInputCost}
                      onChange={(e) => setRenewalInputCost(e.target.value)}
                      className="w-20 px-2 py-1 text-xs font-mono font-bold bg-white border border-cyan-300 rounded-lg text-center"
                    />
                  </div>
                )}
              </div>

              {/* Option 2: Marcar Por Agotar */}
              <button
                type="button"
                onClick={() => handleApplyStateFromPopover('por_agotar')}
                className="w-full p-2.5 rounded-xl border border-amber-300 bg-amber-50 hover:bg-amber-100 text-amber-950 font-bold flex items-center justify-between cursor-pointer transition-colors text-left"
              >
                <span>● Marcar como Por agotar</span>
                <span className="text-[10px] font-normal text-amber-800">Se llena hasta renovar</span>
              </button>

              {/* Option 3: Marcar Agotado */}
              <button
                type="button"
                onClick={() => handleApplyStateFromPopover('agotado')}
                className="w-full p-2.5 rounded-xl border border-rose-300 bg-rose-50 hover:bg-rose-100 text-rose-950 font-bold flex items-center justify-between cursor-pointer transition-colors text-left"
              >
                <span>● Marcar como Agotado</span>
                <span className="text-[10px] font-normal text-rose-800">Requiere renovar</span>
              </button>

              {/* Option 4: Marcar Disponible */}
              <button
                type="button"
                onClick={() => handleApplyStateFromPopover('disponible')}
                className="w-full p-2.5 rounded-xl border border-emerald-300 bg-emerald-50 hover:bg-emerald-100 text-emerald-950 font-bold flex items-center justify-between cursor-pointer transition-colors text-left"
              >
                <span>● Marcar como Disponible</span>
                <span className="text-[10px] font-normal text-emerald-800">En uso</span>
              </button>

            </div>

            <div className="pt-2 border-t border-slate-100 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveDurationPopover(null)}
                className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-800 font-medium"
              >
                Cerrar
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
